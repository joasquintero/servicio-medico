module.exports = {
  extends: 'stylelint-config-suitcss',
};
